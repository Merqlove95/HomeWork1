package com.example.demo.models;

public enum POStatus {
    PENDING, REJECTED, OPEN, CLOSED
}
