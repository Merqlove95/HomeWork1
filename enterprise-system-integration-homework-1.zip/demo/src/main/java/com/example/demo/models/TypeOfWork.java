package com.example.demo.models;

public enum TypeOfWork {
    PREVENTIVE,
    CORRECTIVE,
    OPERATIVE
}
