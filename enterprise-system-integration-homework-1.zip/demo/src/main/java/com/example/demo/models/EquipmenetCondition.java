package com.example.demo.models;

public enum EquipmenetCondition {
    SERVICEABLE,
    UNSERVICEABLE_REPAIRABLE,
    UNSERVICEABLE_INCOMPLETE,
    UNSERVICEABLE_CONDEMNED,
}
