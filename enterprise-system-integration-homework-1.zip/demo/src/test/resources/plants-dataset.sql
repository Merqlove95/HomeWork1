insert into plant_inventory_entry (id, name, description, price)
    values (1, 'Mini excavator', '1.5 Tonne Mini excavator', 150);
insert into plant_inventory_entry (id, name, description, price)
    values (2, 'Mini excavator', '3 Tonne Mini excavator', 200);
insert into plant_inventory_entry (id, name, description, price)
    values (3, 'Midi excavator', '5 Tonne Midi excavator', 250);
insert into plant_inventory_entry (id, name, description, price)
    values (4, 'Midi excavator', '8 Tonne Midi excavator', 300);
insert into plant_inventory_entry (id, name, description, price)
    values (5, 'Maxi excavator', '15 Tonne Large excavator', 400);
insert into plant_inventory_entry (id, name, description, price)
    values (6, 'Maxi excavator', '20 Tonne Large excavator', 450);
insert into plant_inventory_entry (id, name, description, price)
    values (7, 'HS dumper', '1.5 Tonne Hi-Swivel Dumper', 150);
insert into plant_inventory_entry (id, name, description, price)
    values (8, 'FT dumper', '2 Tonne Front Tip Dumper', 180);
insert into plant_inventory_entry (id, name, description, price)
    values (9, 'FT dumper', '2 Tonne Front Tip Dumper', 200);
insert into plant_inventory_entry (id, name, description, price)
    values (10, 'FT dumper', '2 Tonne Front Tip Dumper', 300);
insert into plant_inventory_entry (id, name, description, price)
    values (11, 'FT dumper', '3 Tonne Front Tip Dumper', 400);
insert into plant_inventory_entry (id, name, description, price)
    values (12, 'Loader', 'Hewden Backhoe Loader', 200);
insert into plant_inventory_entry (id, name, description, price)
    values (13, 'D-Truck', '15 Tonne Articulating Dump Truck', 250);
insert into plant_inventory_entry (id, name, description, price)
    values (14, 'D-Truck', '30 Tonne Articulating Dump Truck', 300);

insert into plant_inventory_item (id, plant_info_id, serial_number, equipment_condition)
    values (1, 1, 'A01', 'SERVICEABLE');
insert into plant_inventory_item (id, plant_info_id, serial_number, equipment_condition)
    values (2, 2, 'A02', 'SERVICEABLE');
insert into plant_inventory_item (id, plant_info_id, serial_number, equipment_condition)
    values (3, 3, 'A03', 'UNSERVICEABLE_REPAIRABLE');


insert into plant_reservation (id, plant_id, start_date, end_date)
    values (1, 1, '2017-03-22', '2017-03-24');
insert into plant_reservation (id, plant_id, start_date, end_date)
    values (2, 2, '2017-03-30', '2017-04-01');
insert into plant_reservation (id, plant_id, start_date, end_date)
    values (3, 3, '2017-05-12', '2017-06-01');


insert into maintenance_task (id, description, price, type_of_work, reservation_id, start_date, end_date)
    values (1, 'Description 1', 740, 'CORRECTIVE', 1, '2018-01-02', '2018-01-20');
insert into maintenance_task (id, description, price, type_of_work, reservation_id, start_date, end_date)
    values (2, 'Description 2', 300, 'OPERATIVE', 2, '2016-06-12', '2016-07-01');
insert into maintenance_task (id, description, price, type_of_work, reservation_id, start_date, end_date)
    values (3, 'Description 3', 900, 'CORRECTIVE', 3, '2017-01-10', '2017-01-22');
