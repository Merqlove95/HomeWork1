# Enterprise System Integration - Homework #1

Konstantin Merkulov - (B66272)

Andrei Voitenko -(B32085)

Stanislav Bondarenko (B87756)